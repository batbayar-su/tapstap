﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("After Effects Importer")]
	public class AE_AnimationFade : FsmStateAction {
		public AfterEffectAnimation animation;

		public FsmInt opacityFrom;
		public FsmInt opacityTo;
		public FsmInt time;
		
		public override void OnEnter() {
			
			if(animation != null) {
				animation.OnFadeComplete += OnFadeComplete;
				animation.AnimateOpacity(opacityFrom.Value, opacityTo.Value, time.Value);
			} else {
				Debug.Log("Animation Not Found");
			}	

		}

		private void OnFadeComplete () {
			animation.OnFadeComplete -= OnFadeComplete;
			Finish();
		}
		
	}
}