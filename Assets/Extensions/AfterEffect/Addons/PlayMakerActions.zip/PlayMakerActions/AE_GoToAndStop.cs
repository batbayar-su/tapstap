﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("After Effects Importer")]
	public class AE_GoToAndStop : FsmStateAction {
		public AfterEffectAnimation animation;
		public FsmInt index;


		public override void OnEnter() {
			
			if(animation != null) {
				animation.GoToAndStop(index.Value);
			} else {
				Debug.Log("Animation Not Found");
			}
			
			Finish();
		}
		
	}
}
