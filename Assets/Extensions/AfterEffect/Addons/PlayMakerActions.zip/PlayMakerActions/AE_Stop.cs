﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("After Effects Importer")]
	public class AE_Stop : FsmStateAction {
		public AfterEffectAnimation animation;
		
		public override void OnEnter() {
			
			if(animation != null) {
				animation.Stop();
			} else {
				Debug.Log("Animation Not Found");
			}
			
			Finish();
		}
		
	}
}
