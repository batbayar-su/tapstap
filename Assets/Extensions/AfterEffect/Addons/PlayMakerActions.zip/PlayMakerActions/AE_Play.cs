﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("After Effects Importer")]
	public class AE_Play : FsmStateAction {
		public AfterEffectAnimation animation;

		public override void OnEnter() {
			
			if(animation != null) {
				animation.Play();
			} else {
				Debug.Log("Animation Not Found");
			}
				
			Finish();
		}

	}
}
