﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("After Effects Importer")]
	public class AE_AnimationEvents : FsmStateAction {

		public AfterEffectAnimation animation;


		public FsmInt CurrentIndex;
		

		public FsmEvent OnEnterFrameEvent;
		public FsmEvent OnAnimationCompleteEvent;
	
	

		public override void OnEnter() {


			if(animation != null) {
				animation.OnEnterFrame += OnEnterFrame;
				animation.OnAnimationComplete += OnAnimationComplete;
			} else {
				Debug.Log("Animation Not Found");
			}
			
	
		}
		
		

		void OnEnterFrame (int index) {
			CurrentIndex = index;
			Fsm.Event(OnEnterFrameEvent);
		}

		void OnAnimationComplete () {
			Fsm.Event(OnAnimationCompleteEvent);
		}
	}
}

